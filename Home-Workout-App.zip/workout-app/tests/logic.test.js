import { describe, expect, it } from 'vitest'
import { LM } from '../src/lib/pose/landmarks'
import { createSquatDetector } from '../src/lib/pose/detectors/squat'
import { createPlankDetector } from '../src/lib/pose/detectors/plank'
import { createWallSitDetector } from '../src/lib/pose/detectors/wallSit'
import { createShoulderPressDetector } from '../src/lib/pose/detectors/shoulderPress'
import { createStandingRowDetector } from '../src/lib/pose/detectors/standingRow'
import { calibrateRest } from '../src/lib/pose/calibration'
import { nudgeNextTarget, buildTargets, cleanRateFor } from '../src/lib/pose/session'
import { adaptPlan, decideAction, diffPlans, generateInitialPlan, summariseAdaptation } from '../src/lib/planGenerator'
import { EXERCISES, exercisesFor } from '../src/data/exercises'
import { isCameraDetectable } from '../src/lib/pose/detectorRegistry'
import { sessionStats, volumeSeries, weeklyCompletion } from '../src/lib/progress'

// 33 landmarks, all visible, parked in a corner unless overridden.
function lm(over = {}) {
  const a = Array.from({ length: 33 }, () => ({ x: 0.05, y: 0.05, visibility: 1 }))
  for (const [i, p] of Object.entries(over)) a[i] = { visibility: 1, ...p }
  return a
}

// A standing body whose both knees are bent to `deg` degrees.
function squatFrame(deg) {
  const hip = { x: 0.5, y: 0.4 }
  const knee = { x: 0.5, y: 0.6 }
  const r = (deg * Math.PI) / 180
  const ankle = { x: knee.x + 0.2 * Math.sin(r), y: knee.y - 0.2 * Math.cos(r) }
  return lm({
    [LM.LEFT_SHOULDER]: { x: 0.45, y: 0.2 }, [LM.RIGHT_SHOULDER]: { x: 0.55, y: 0.2 },
    [LM.LEFT_HIP]: hip, [LM.RIGHT_HIP]: hip,
    [LM.LEFT_KNEE]: knee, [LM.RIGHT_KNEE]: knee,
    [LM.LEFT_ANKLE]: ankle, [LM.RIGHT_ANKLE]: ankle,
  })
}

function run(det, frames, stepMs = 33) {
  let t = 1000
  let last
  let reps = 0
  for (const f of frames) {
    last = det.update(f, (t += stepMs))
    if (last.repCompleted) reps++
  }
  return { reps, last }
}

const sweep = (from, to, n) => Array.from({ length: n }, (_, i) => from + ((to - from) * i) / (n - 1))
const cycle = (hi, lo) => [...sweep(hi, lo, 12), ...sweep(lo, hi, 12)]

describe('rep counting', () => {
  it('counts five clean squats', () => {
    const angles = Array.from({ length: 5 }, () => cycle(175, 90)).flat()
    expect(run(createSquatDetector(), angles.map(squatFrame)).reps).toBe(5)
  })

  it('does not count shallow squats', () => {
    const angles = Array.from({ length: 4 }, () => cycle(175, 130)).flat()
    expect(run(createSquatDetector(), angles.map(squatFrame)).reps).toBe(0)
  })

  it('flags knees caving in', () => {
    const f = squatFrame(120)
    f[LM.LEFT_KNEE].x = 0.48
    f[LM.RIGHT_KNEE].x = 0.52
    f[LM.LEFT_ANKLE].x = 0.4
    f[LM.RIGHT_ANKLE].x = 0.6
    const r = createSquatDetector().update(f, 2000)
    expect(r.formOk).toBe(false)
  })

  it('calibration lets a user with a bent-knee stance finish reps', () => {
    // This person only ever straightens to 150 degrees.
    const angles = Array.from({ length: 4 }, () => cycle(150, 90)).flat()
    expect(run(createSquatDetector(), angles.map(squatFrame)).reps).toBe(0)

    const det = createSquatDetector()
    const cal = calibrateRest(Array(30).fill(150), det.restValue, det.peakValue)
    expect(cal.used).toBe(true)
    det.setRestValue(cal.restValue)
    expect(run(det, angles.map(squatFrame)).reps).toBe(4)
  })
})

describe('calibration guard rails', () => {
  it('ignores a reading that is nowhere near the start position', () => {
    const r = calibrateRest(Array(30).fill(95), 160, 100)
    expect(r.used).toBe(false)
    expect(r.restValue).toBe(160)
  })
  it('ignores too few samples', () => {
    expect(calibrateRest([170, 171], 160, 100).used).toBe(false)
  })
  it('keeps the threshold close to the default', () => {
    const r = calibrateRest(Array(30).fill(215), 160, 100) // implausibly high
    expect(r.used).toBe(false)
    const ok = calibrateRest(Array(30).fill(178), 160, 100)
    expect(ok.restValue).toBeGreaterThan(139)
    expect(ok.restValue).toBeLessThan(181)
  })
})

describe('hold detectors', () => {
  const plankBody = (hipDrop = 0) =>
    lm({
      [LM.LEFT_SHOULDER]: { x: 0.8, y: 0.5 }, [LM.RIGHT_SHOULDER]: { x: 0.8, y: 0.5 },
      [LM.LEFT_HIP]: { x: 0.5, y: 0.6 + hipDrop }, [LM.RIGHT_HIP]: { x: 0.5, y: 0.6 + hipDrop },
      [LM.LEFT_ANKLE]: { x: 0.2, y: 0.7 }, [LM.RIGHT_ANKLE]: { x: 0.2, y: 0.7 },
      [LM.LEFT_KNEE]: { x: 0.35, y: 0.65 }, [LM.RIGHT_KNEE]: { x: 0.35, y: 0.65 },
    })

  it('times a straight plank and pauses when hips sag', () => {
    const det = createPlankDetector()
    let t = 0
    let r
    for (let i = 0; i < 30; i++) r = det.update(plankBody(), (t += 33))
    expect(r.holding).toBe(true)
    const held = r.heldMs
    expect(held).toBeGreaterThan(900)
    for (let i = 0; i < 30; i++) r = det.update(plankBody(0.12), (t += 33))
    expect(r.holding).toBe(false)
    expect(r.formMessage).toMatch(/sagging/)
    expect(r.heldMs).toBe(held)
  })

  it('flags piked hips', () => {
    const r = createPlankDetector().update(plankBody(-0.12), 100)
    expect(r.formMessage).toMatch(/too high/)
  })

  it('rejects a standing body as a plank', () => {
    const r = createPlankDetector().update(squatFrame(175), 100)
    expect(r.holding).toBe(false)
  })

  it('does not let a stalled frame add a big jump of time', () => {
    const det = createPlankDetector()
    det.update(plankBody(), 0)
    expect(det.update(plankBody(), 5000).heldMs).toBeLessThanOrEqual(250)
  })

  const sit = (kneeDeg, lean = 0) => {
    const hip = { x: 0.4, y: 0.5 }
    const knee = { x: 0.6, y: 0.5 }
    const r = (kneeDeg * Math.PI) / 180
    // angle at knee between knee->hip (pointing left) and knee->ankle
    const ankle = { x: knee.x - 0.2 * Math.cos(r), y: knee.y + 0.2 * Math.sin(r) }
    return lm({
      [LM.LEFT_SHOULDER]: { x: 0.4 + lean, y: 0.25 }, [LM.RIGHT_SHOULDER]: { x: 0.4 + lean, y: 0.25 },
      [LM.LEFT_HIP]: hip, [LM.RIGHT_HIP]: hip,
      [LM.LEFT_KNEE]: knee, [LM.RIGHT_KNEE]: knee,
      [LM.LEFT_ANKLE]: ankle, [LM.RIGHT_ANKLE]: ankle,
    })
  }
  it('wall sit: counts only near 90 degrees with an upright back', () => {
    const det = createWallSitDetector()
    expect(det.update(sit(90), 100).holding).toBe(true)
    expect(det.update(sit(150), 200).formMessage).toMatch(/lower/)
    expect(det.update(sit(50), 300).formMessage).toMatch(/up a little/)
    expect(det.update(sit(90, 0.2), 400).formMessage).toMatch(/back flat/)
  })
})

describe('equipment exercises', () => {
  const press = (wristRise) =>
    lm({
      [LM.LEFT_SHOULDER]: { x: 0.4, y: 0.3 }, [LM.RIGHT_SHOULDER]: { x: 0.6, y: 0.3 },
      [LM.LEFT_HIP]: { x: 0.42, y: 0.6 }, [LM.RIGHT_HIP]: { x: 0.58, y: 0.6 },
      [LM.LEFT_WRIST]: { x: 0.35, y: 0.3 - wristRise * 0.3 }, [LM.RIGHT_WRIST]: { x: 0.65, y: 0.3 - wristRise * 0.3 },
      [LM.LEFT_ELBOW]: { x: 0.3, y: 0.35 }, [LM.RIGHT_ELBOW]: { x: 0.7, y: 0.35 },
      [LM.LEFT_KNEE]: { x: 0.42, y: 0.8 }, [LM.RIGHT_KNEE]: { x: 0.58, y: 0.8 },
      [LM.LEFT_ANKLE]: { x: 0.42, y: 0.95 }, [LM.RIGHT_ANKLE]: { x: 0.58, y: 0.95 },
    })
  it('counts shoulder presses from wrist height', () => {
    const rises = Array.from({ length: 4 }, () => [...sweep(0.1, 1.05, 14), ...sweep(1.05, 0.1, 14)]).flat()
    expect(run(createShoulderPressDetector(), rises.map(press)).reps).toBe(4)
  })

  const row = (deg) => {
    const sh = { x: 0.5, y: 0.3 }
    const el = { x: 0.5, y: 0.45 }
    const r = (deg * Math.PI) / 180
    const wr = { x: el.x + 0.15 * Math.sin(r), y: el.y - 0.15 * Math.cos(r) }
    return lm({
      [LM.LEFT_SHOULDER]: sh, [LM.RIGHT_SHOULDER]: sh, [LM.LEFT_ELBOW]: el, [LM.RIGHT_ELBOW]: el,
      [LM.LEFT_WRIST]: wr, [LM.RIGHT_WRIST]: wr,
      [LM.LEFT_HIP]: { x: 0.5, y: 0.6 }, [LM.RIGHT_HIP]: { x: 0.5, y: 0.6 },
    })
  }
  it('counts band rows from elbow angle', () => {
    // angle at elbow between elbow->shoulder (up) and elbow->wrist
    const angles = Array.from({ length: 3 }, () => cycle(170, 70)).flat()
    expect(run(createStandingRowDetector(), angles.map(row)).reps).toBe(3)
  })
})

describe('in-session nudge', () => {
  it('trims the next set when form slipped', () => {
    expect(nudgeNextTarget(12, 12, 0.5)).toEqual({ target: 10, trimmed: true })
  })
  it('never trims below 60% of the original', () => {
    expect(nudgeNextTarget(10, 6, 0.1).target).toBe(6)
  })
  it('restores the original target after a clean set', () => {
    expect(nudgeNextTarget(12, 10, 0.95)).toEqual({ target: 12, trimmed: false })
  })
  it('builds one target per set, in seconds for holds', () => {
    expect(buildTargets({ sets: 3, reps: 12 }, 'reps')).toEqual([12, 12, 12])
    expect(buildTargets({ sets: 2, holdSeconds: 40 }, 'hold')).toEqual([40, 40])
  })
  it('clean rate', () => {
    expect(cleanRateFor(8, 2)).toBe(0.8)
    expect(cleanRateFor(0, 0)).toBeNull()
  })
})

describe('weekly adaptation', () => {
  const plan = {
    weekNumber: 1,
    days: [{ dayIndex: 0, exercises: [
      { exerciseId: 'squat', sets: 3, reps: 12, holdSeconds: null },
      { exerciseId: 'pushup', sets: 3, reps: 10, holdSeconds: null },
      { exerciseId: 'plank', sets: 3, reps: null, holdSeconds: 30 },
    ] }],
  }
  const log = (entries) => ({ weekNumber: 1, entries })

  it('decides actions', () => {
    expect(decideAction(1, 0.9)).toBe('progress')
    expect(decideAction(1, null)).toBe('progress')
    expect(decideAction(1, 0.5)).toBe('hold_form')
    expect(decideAction(0.5, 0.95)).toBe('hold_completion')
  })

  it('progresses clean work, holds poor form, holds low completion', () => {
    const next = adaptPlan(plan, log({
      squat: { attempted: 1, completed: 1, cleanRate: 0.9 },
      pushup: { attempted: 1, completed: 1, cleanRate: 0.5 },
      plank: { attempted: 1, completed: 0, cleanRate: null },
    }))
    const [sq, pu, pl] = next.days[0].exercises
    expect(sq.sets).toBe(4)
    expect(sq.reps).toBe(13)
    expect(pu).toMatchObject({ sets: 3, reps: 10 })
    expect(pl).toMatchObject({ sets: 3, holdSeconds: 30 })
    expect(next.weekNumber).toBe(2)
    expect(next.adaptation.pushup.action).toBe('hold_form')
    expect(next.adaptation.plank.action).toBe('hold_completion')

    const s = summariseAdaptation(plan, next, (id) => id)
    expect(s).toEqual({ increased: ['squat'], held: ['plank'], heldForForm: ['pushup'], atCap: [] })
    expect(diffPlans(plan, next, (id) => id).find((r) => r.exerciseId === 'squat')).toMatchObject({ from: '3 × 12', to: '4 × 13', changed: true })
  })

  it('honours the safety caps over many weeks and never reduces', () => {
    let p = plan
    for (let w = 0; w < 30; w++) {
      const entries = Object.fromEntries(p.days[0].exercises.map((e) => [e.exerciseId, { attempted: 1, completed: 1, cleanRate: 1 }]))
      const before = p.days[0].exercises
      p = adaptPlan(p, log(entries))
      p.days[0].exercises.forEach((e, i) => {
        expect(e.sets).toBeGreaterThanOrEqual(before[i].sets)
        expect(e.sets).toBeLessThanOrEqual(5)
        if (e.reps != null) expect(e.reps).toBeLessThanOrEqual(EXERCISES.find((x) => x.id === e.exerciseId).baseReps * 2)
        if (e.holdSeconds != null) expect(e.holdSeconds).toBeLessThanOrEqual(90)
      })
    }
    expect(p.adaptation.squat.action).toBe('at_cap')
  })
})

describe('plan generation', () => {
  it('every goal / equipment / space combination yields a plan', () => {
    for (const goal of ['general_fitness', 'strength', 'mobility', 'weight_loss'])
      for (const equipment of ['none', 'dumbbells', 'resistance_band', 'full_gym'])
        for (const space of ['small', 'medium', 'large']) {
          expect(exercisesFor({ goal, equipment, space }).length).toBeGreaterThan(0)
          const p = generateInitialPlan({ goal, equipment, space, frequency: 4 })
          expect(p.days).toHaveLength(4)
          p.days.forEach((d) => expect(d.exercises.length).toBeGreaterThanOrEqual(1))
        }
  })
  it('only the world greatest stretch is manual', () => {
    expect(EXERCISES.filter((e) => !isCameraDetectable(e.id)).map((e) => e.id)).toEqual(['world_greatest_stretch'])
  })
})

describe('progress helpers', () => {
  it('series and stats', () => {
    const logs = [
      { weekNumber: 2, entries: { a: { attempted: 2, completed: 2 } } },
      { weekNumber: 1, entries: { a: { attempted: 2, completed: 1 } } },
    ]
    expect(weeklyCompletion(logs)).toEqual([{ week: 1, rate: 0.5 }, { week: 2, rate: 1 }])
    const plans = [
      { weekNumber: 1, days: [{ exercises: [{ exerciseId: 'squat', sets: 3, reps: 12 }] }] },
      { weekNumber: 2, days: [{ exercises: [{ exerciseId: 'squat', sets: 4, reps: 13 }] }] },
    ]
    expect(volumeSeries(plans, 'squat').map((x) => x.value)).toEqual([36, 52])
    const st = sessionStats([
      { kind: 'reps', repsCounted: 10, selfCount: 10, cleanRate: 1 },
      { kind: 'reps', repsCounted: 8, selfCount: 10, cleanRate: 0.5 },
    ])
    expect(st.counted).toBe(18)
    expect(st.cleanRate).toBeCloseTo(0.75)
    expect(st.agreement).toBeCloseTo(0.9)
  })
})
