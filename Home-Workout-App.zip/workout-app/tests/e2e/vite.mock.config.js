import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { viteSingleFile } from 'vite-plugin-singlefile'
import path from 'node:path'

export default defineConfig({
  root: path.resolve(__dirname, '../..'),
  plugins: [react(), tailwindcss(), viteSingleFile()],
  resolve: {
    alias: [{ find: /^.*\/lib\/pose\/poseEngine$/, replacement: path.resolve(__dirname, 'mockPoseEngine.js') }],
  },
  build: { outDir: process.env.MOCK_OUT, emptyOutDir: true },
})
