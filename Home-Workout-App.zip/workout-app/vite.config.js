import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { VitePWA } from 'vite-plugin-pwa'
import { viteSingleFile } from 'vite-plugin-singlefile'

// Two build modes, switched by the SINGLEFILE env var:
// - normal build: proper multi-file output + PWA manifest/service worker,
//   for real deployment to Vercel/Netlify/GitHub Pages.
// - singlefile build: everything inlined into one HTML file, used only to
//   produce a quick, shareable preview (e.g. as a published chat artifact).
//   PWA plugin is skipped in this mode since a service worker requires a
//   real origin/multiple files. NOTE: the camera will NOT work inside a
//   sandboxed artifact preview iframe — getUserMedia is blocked there. Use
//   this build only to preview onboarding/plan UI, not camera detection.
const singleFile = process.env.SINGLEFILE === 'true'

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    ...(singleFile
      ? [viteSingleFile()]
      : [
          VitePWA({
            registerType: 'autoUpdate',
            includeAssets: ['icons/icon-192.png', 'icons/icon-512.png'],
            manifest: {
              name: 'Adaptive Home Workout',
              short_name: 'Workout',
              description: 'Adaptive home workout planning with camera-based exercise verification.',
              theme_color: '#12181B',
              background_color: '#12181B',
              display: 'standalone',
              start_url: '/',
              icons: [
                { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
                { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
                { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
              ],
            },
            workbox: {
              globPatterns: ['**/*.{js,css,html,png,svg,ico}'],
              // MediaPipe's .wasm/.task model files are fetched from a CDN
              // at runtime, not bundled, so no extra glob pattern needed
              // here — but don't let workbox try to precache them either.
              maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
            },
          }),
        ]),
  ],
  build: {
    outDir: singleFile ? 'dist-singlefile' : 'dist',
    assetsInlineLimit: singleFile ? 100000000 : 4096,
    cssCodeSplit: !singleFile,
  },
})
