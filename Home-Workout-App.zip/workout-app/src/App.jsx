import { useEffect, useState } from 'react'
import Landing from './components/Landing'
import Onboarding from './components/Onboarding'
import PlanView, { dayExerciseKey } from './components/PlanView'
import Progress from './components/Progress'
import CameraSession from './components/CameraSession'
import TopNav from './components/TopNav'
import { generateInitialPlan, adaptPlan, summariseAdaptation } from './lib/planGenerator'
import { storage } from './lib/storage'
import { exerciseById } from './data/exercises'

const exerciseName = (id) => exerciseById(id)?.name ?? id

export default function App() {
  const [screen, setScreen] = useState('landing') // landing | app
  const [view, setView] = useState('plan') // plan | progress
  const [profile, setProfile] = useState(undefined) // undefined = loading, null = none saved yet
  const [plan, setPlan] = useState(null)
  const [plans, setPlans] = useState([])
  // completion: { "dayIndex:exerciseId": { done, verifiedByCamera?, repsDetected?, ... } }
  const [completion, setCompletion] = useState({})
  const [adaptationSummary, setAdaptationSummary] = useState(null)
  const [session, setSession] = useState(null) // { dayIndex, entry } while the camera screen is open
  const [editing, setEditing] = useState(false)
  const [error, setError] = useState(null)

  // Load any saved profile, plans and the week in progress.
  useEffect(() => {
    const savedProfile = storage.getProfile()
    const saved = storage.getPlans()
    const current = saved[saved.length - 1] ?? null
    setProfile(savedProfile)
    setPlans(saved)
    if (savedProfile && current) {
      setPlan(current)
      setCompletion(storage.getCompletion(current.weekNumber))
    }
  }, [])

  function updateCompletion(updater) {
    setCompletion((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : updater
      if (plan) storage.saveCompletion(plan.weekNumber, next)
      return next
    })
  }

  function handleOnboardingComplete(newProfile) {
    try {
      const fresh = generateInitialPlan(newProfile)
      storage.saveProfile(newProfile)
      setProfile(newProfile)
      setError(null)
      if (editing && plan) {
        // Editing the setup keeps the week number and history, but rebuilds the exercises.
        const rebuilt = { ...fresh, weekNumber: plan.weekNumber }
        const all = storage.getPlans()
        all[all.length - 1] = rebuilt
        storage.savePlans(all)
        storage.saveCompletion(rebuilt.weekNumber, {})
        setPlans(all)
        setPlan(rebuilt)
        setCompletion({})
        setEditing(false)
      } else {
        storage.savePlans([fresh])
        setPlans([fresh])
        setPlan(fresh)
        setCompletion({})
        storage.saveCompletion(1, {})
      }
      setView('plan')
    } catch (e) {
      setError(e.message)
    }
  }

  function handleToggleComplete(dayIndex, exerciseId) {
    updateCompletion((prev) => {
      const key = dayExerciseKey(dayIndex, exerciseId)
      const wasDone = !!prev[key]?.done
      return { ...prev, [key]: { done: !wasDone } }
    })
  }

  function handleCameraFinish(result) {
    const { dayIndex } = session
    const key = dayExerciseKey(dayIndex, result.exerciseId)
    const done = result.setsCompleted >= result.setsPlanned
    updateCompletion((prev) => ({
      ...prev,
      [key]: {
        done,
        verifiedByCamera: true,
        repsDetected: result.repsCounted,
        heldSeconds: result.heldSeconds || undefined,
        setsCompleted: result.setsCompleted,
        cleanRate: result.cleanRate,
      },
    }))
    // Numbers only: no frames, no landmarks, ever.
    storage.addSession({
      at: new Date().toISOString(),
      week: plan.weekNumber,
      ...result,
    })
    setSession(null)
  }

  function handleFinishWeek() {
    // Collapse completion state into the per-exercise log that the
    // adaptation engine reads: how often it was completed, and (where the
    // camera checked it) how clean the form was.
    const entries = {}
    for (const day of plan.days) {
      for (const entry of day.exercises) {
        const state = completion[dayExerciseKey(day.dayIndex, entry.exerciseId)]
        const b = entries[entry.exerciseId] ?? { attempted: 0, completed: 0, verified: 0, cleanSum: 0, cleanN: 0 }
        b.attempted += 1
        if (state?.done) b.completed += 1
        if (state?.verifiedByCamera) b.verified += 1
        if (state?.cleanRate != null) {
          b.cleanSum += state.cleanRate
          b.cleanN += 1
        }
        entries[entry.exerciseId] = b
      }
    }
    for (const b of Object.values(entries)) {
      b.cleanRate = b.cleanN ? b.cleanSum / b.cleanN : null
      delete b.cleanSum
      delete b.cleanN
    }
    storage.saveLogForWeek(plan.weekNumber, entries)

    const nextPlan = adaptPlan(plan, { weekNumber: plan.weekNumber, entries })
    const all = [...storage.getPlans(), nextPlan]
    storage.savePlans(all)
    storage.saveCompletion(nextPlan.weekNumber, {})
    setPlans(all)
    setAdaptationSummary(summariseAdaptation(plan, nextPlan, exerciseName))
    setPlan(nextPlan)
    setCompletion({})
    window.scrollTo?.({ top: 0 })
  }

  function handleReset() {
    storage.reset()
    setProfile(null)
    setPlan(null)
    setPlans([])
    setCompletion({})
    setAdaptationSummary(null)
    setSession(null)
    setEditing(false)
  }

  if (profile === undefined) return null // brief flash while localStorage is read

  if (screen === 'landing') {
    return (
      <Landing
        onStart={() => { setScreen('app'); window.scrollTo?.({ top: 0 }) }}
        hasPlan={!!(profile && plan)}
        weekNumber={plan?.weekNumber}
      />
    )
  }

  if (!profile || !plan || editing) {
    return (
      <Onboarding
        key={editing ? 'edit' : 'new'}
        onComplete={handleOnboardingComplete}
        initial={editing ? profile : null}
        onExit={editing ? () => setEditing(false) : () => setScreen('landing')}
        error={error}
      />
    )
  }

  if (session) {
    return (
      <CameraSession
        key={`${session.dayIndex}:${session.entry.exerciseId}`}
        exercise={exerciseById(session.entry.exerciseId)}
        entry={session.entry}
        onFinish={handleCameraFinish}
        onCancel={() => setSession(null)}
      />
    )
  }

  return (
    <div className="min-h-full">
      <TopNav view={view} onChange={setView} onHome={() => setScreen('landing')} />
      {view === 'plan' ? (
        <PlanView
          plan={plan}
          completion={completion}
          onToggleComplete={handleToggleComplete}
          onStartCamera={(dayIndex, entry) => setSession({ dayIndex, entry })}
          onFinishWeek={handleFinishWeek}
          adaptationSummary={adaptationSummary}
          onDismissSummary={() => setAdaptationSummary(null)}
          onReset={handleReset}
          onEditSetup={() => setEditing(true)}
        />
      ) : (
        <Progress plans={plans} />
      )}
    </div>
  )
}
