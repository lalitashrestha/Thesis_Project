import { useMemo, useState } from 'react'
import { exerciseById } from '../data/exercises'
import { isCameraDetectable } from '../lib/pose/detectorRegistry'
import { ExerciseFigure } from './figures'

const DAY_LABELS = ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7']

export function dayExerciseKey(dayIndex, exerciseId) {
  return `${dayIndex}:${exerciseId}`
}

export default function PlanView({
  plan,
  completion,
  onToggleComplete,
  onStartCamera,
  onFinishWeek,
  adaptationSummary,
  onDismissSummary,
  onReset,
  onEditSetup,
}) {
  const firstOpenDay = useMemo(() => {
    const i = plan.days.findIndex((d) =>
      d.exercises.some((e) => !completion[dayExerciseKey(d.dayIndex, e.exerciseId)]?.done)
    )
    return i === -1 ? 0 : i
    // only on first mount for this week
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plan.weekNumber])
  const [activeDay, setActiveDay] = useState(firstOpenDay)
  const [openId, setOpenId] = useState(null)
  const [confirmingReset, setConfirmingReset] = useState(false)
  const [confirmingFinish, setConfirmingFinish] = useState(false)
  const day = plan.days[activeDay] ?? plan.days[0]

  const weekProgress = useMemo(() => {
    const total = plan.days.reduce((n, d) => n + d.exercises.length, 0)
    const done = plan.days.reduce(
      (n, d) => n + d.exercises.filter((e) => completion[dayExerciseKey(d.dayIndex, e.exerciseId)]?.done).length,
      0
    )
    return { done, total }
  }, [plan, completion])
  const pct = weekProgress.total ? Math.round((weekProgress.done / weekProgress.total) * 100) : 0

  return (
    <div className="max-w-md mx-auto px-6 pt-6 pb-16">
      {adaptationSummary && <AdaptationBanner summary={adaptationSummary} onDismiss={onDismissSummary} />}

      <header className="mb-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-sm text-[var(--color-sage)] font-medium">Week {plan.weekNumber}</p>
            <h1 className="font-display text-2xl font-semibold mt-1">Your plan</h1>
          </div>
          <div className="flex items-center gap-3 mt-1">
            <button onClick={onEditSetup} className="text-xs text-[var(--color-muted)] underline underline-offset-2">Edit setup</button>
            <ResetControl
              confirming={confirmingReset}
              onRequestReset={() => setConfirmingReset(true)}
              onCancel={() => setConfirmingReset(false)}
              onConfirm={onReset}
            />
          </div>
        </div>
        <div className="mt-4 h-1.5 rounded-full bg-[var(--color-surface-raised)] overflow-hidden" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Week progress">
          <div className="h-full bg-[var(--color-amber)] rounded-full transition-[width] duration-300" style={{ width: `${pct}%` }} />
        </div>
        <p className="text-sm text-[var(--color-muted)] mt-2">
          {weekProgress.done} of {weekProgress.total} exercises done this week
        </p>
      </header>

      <div className="flex gap-2 overflow-x-auto pb-1 mb-5 -mx-1 px-1">
        {plan.days.map((d, i) => {
          const dayDone = d.exercises.every((e) => completion[dayExerciseKey(d.dayIndex, e.exerciseId)]?.done)
          return (
            <button
              key={d.dayIndex}
              onClick={() => setActiveDay(i)}
              className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium border transition-colors ${
                activeDay === i
                  ? 'bg-[var(--color-amber)] text-[var(--color-ink)] border-[var(--color-amber)]'
                  : 'border-[var(--color-border)] text-[var(--color-muted)]'
              }`}
            >
              {DAY_LABELS[d.dayIndex] ?? `Day ${d.dayIndex + 1}`}
              {dayDone && <span className="ml-1.5" aria-label="complete">{'✓'}</span>}
            </button>
          )
        })}
      </div>

      <ul className="flex flex-col gap-3">
        {day.exercises.map((entry) => {
          const ex = exerciseById(entry.exerciseId)
          const key = dayExerciseKey(day.dayIndex, entry.exerciseId)
          const state = completion[key]
          const done = !!state?.done
          const detectable = isCameraDetectable(entry.exerciseId)
          const open = openId === key

          return (
            <li key={key} className="rounded-2xl border bg-[var(--color-surface)] overflow-hidden transition-colors" style={{ borderColor: done ? 'var(--color-amber)' : 'var(--color-border)' }}>
              <div className="flex items-center gap-3 p-3">
                <button
                  onClick={() => setOpenId(open ? null : key)}
                  aria-expanded={open}
                  className="flex items-center gap-3 min-w-0 flex-1 text-left"
                >
                  <span className="h-14 w-14 shrink-0 rounded-xl bg-[var(--color-surface-raised)] grid place-items-center">
                    <ExerciseFigure id={entry.exerciseId} className="h-11 w-11" stroke={7} showJoints={false} />
                  </span>
                  <span className="min-w-0">
                    <span className="block font-medium leading-snug">{ex.name}</span>
                    <span className="block text-sm text-[var(--color-muted)]">
                      {entry.holdSeconds ? `${entry.sets} sets × ${entry.holdSeconds}s hold` : `${entry.sets} sets × ${entry.reps} reps`}
                    </span>
                    {state?.verifiedByCamera && (
                      <span className="block text-xs text-[var(--color-sage)] mt-0.5">
                        {state.heldSeconds ? `${state.heldSeconds}s held` : `${state.repsDetected} reps`} verified by camera
                        {state.cleanRate != null && `, ${Math.round(state.cleanRate * 100)}% clean`}
                      </span>
                    )}
                    {state && !state.verifiedByCamera && done && (
                      <span className="block text-xs text-[var(--color-muted)] mt-0.5">Marked done by you</span>
                    )}
                  </span>
                </button>

                <div className="shrink-0 flex items-center gap-2">
                  {detectable && (
                    <button
                      onClick={() => onStartCamera(day.dayIndex, entry)}
                      className={`px-3.5 py-2 rounded-full text-xs font-medium border transition-colors ${
                        done && state?.verifiedByCamera
                          ? 'bg-[var(--color-amber)] text-[var(--color-ink)] border-[var(--color-amber)]'
                          : 'border-[var(--color-amber)] text-[var(--color-amber)]'
                      }`}
                    >
                      {done && state?.verifiedByCamera ? 'Redo' : 'Start'}
                    </button>
                  )}
                  <button
                    onClick={() => onToggleComplete(day.dayIndex, entry.exerciseId)}
                    aria-pressed={done}
                    aria-label={done ? `Mark ${ex.name} not done` : `Mark ${ex.name} done`}
                    className={`h-9 w-9 rounded-full border flex items-center justify-center transition-colors ${
                      done ? 'bg-[var(--color-amber)] border-[var(--color-amber)] text-[var(--color-ink)]' : 'border-[var(--color-border)] text-transparent hover:text-[var(--color-muted)]'
                    }`}
                  >
                    {'✓'}
                  </button>
                </div>
              </div>

              {open && (
                <div className="border-t border-[var(--color-border)] px-4 py-4 grid grid-cols-[96px_1fr] gap-4 items-start bg-[var(--color-ink)]/40">
                  <div className="rounded-xl bg-[var(--color-surface-raised)] p-1.5">
                    <ExerciseFigure id={entry.exerciseId} className="w-full" />
                  </div>
                  <div>
                    <ol className="list-decimal list-inside space-y-1 text-xs leading-snug text-[var(--color-cream)]/90">
                      {ex.howTo?.map((t, i) => <li key={i}>{t}</li>)}
                    </ol>
                    {ex.cameraTip && <p className="text-xs text-[var(--color-sage)] mt-3 leading-relaxed">Camera: {ex.cameraTip}</p>}
                  </div>
                </div>
              )}
            </li>
          )
        })}
      </ul>

      <p className="text-xs text-[var(--color-muted)] mt-6 leading-relaxed">
        Tap <span className="text-[var(--color-amber)]">Start</span> to have your camera count the exercise, or tick it off
        yourself. Camera-verified work also feeds the form-quality check that decides next week's progression.
        Tap an exercise to see how it is done.
      </p>

      {confirmingFinish ? (
        <div className="mt-8 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-4">
          <p className="text-sm">
            {weekProgress.done < weekProgress.total
              ? `${weekProgress.total - weekProgress.done} exercises are not done yet. Finish the week anyway?`
              : 'Finish this week and build week ' + (plan.weekNumber + 1) + '?'}
          </p>
          <div className="mt-3 flex gap-2">
            <button onClick={() => { setConfirmingFinish(false); onFinishWeek() }} className="flex-1 font-display font-semibold px-4 py-2.5 rounded-full bg-[var(--color-amber)] text-[var(--color-ink)]">Yes, adapt my plan</button>
            <button onClick={() => setConfirmingFinish(false)} className="px-4 py-2.5 rounded-full border border-[var(--color-border)] text-sm text-[var(--color-muted)]">Not yet</button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setConfirmingFinish(true)}
          className="w-full mt-8 font-display font-semibold px-6 py-3.5 rounded-full border border-[var(--color-amber)] text-[var(--color-amber)] hover:bg-[var(--color-surface-raised)] transition-colors"
        >
          Finish week & adapt plan
        </button>
      )}
    </div>
  )
}

function ResetControl({ confirming, onRequestReset, onCancel, onConfirm }) {
  if (confirming) {
    return (
      <div className="shrink-0 flex items-center gap-2 text-xs">
        <span className="text-[var(--color-muted)]">Erase everything?</span>
        <button onClick={onConfirm} className="text-[var(--color-amber)] font-medium">Yes</button>
        <button onClick={onCancel} className="text-[var(--color-muted)]">No</button>
      </div>
    )
  }
  return (
    <button onClick={onRequestReset} className="shrink-0 text-xs text-[var(--color-muted)] underline underline-offset-2">
      Start over
    </button>
  )
}

function AdaptationBanner({ summary, onDismiss }) {
  const { increased, held, heldForForm, atCap } = summary
  const lines = []
  if (increased.length) lines.push(<span key="i"><span className="text-[var(--color-amber)] font-medium">{increased.join(', ')}</span> went up for consistent, clean work.</span>)
  if (heldForForm.length) lines.push(<span key="f"><span className="text-[var(--color-sage)] font-medium">{heldForForm.join(', ')}</span> held steady: the camera saw form slipping, so technique comes first.</span>)
  if (held.length) lines.push(<span key="h">{held.join(', ')} held steady (completion was under 80%).</span>)
  if (atCap.length) lines.push(<span key="c">{atCap.join(', ')} reached the safety cap.</span>)

  return (
    <div className="rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)] px-4 py-3.5 mb-6">
      <div className="flex items-start justify-between gap-3">
        <div className="text-sm space-y-1.5 leading-relaxed">
          <p className="font-display font-semibold">Your new plan is ready</p>
          {lines.map((l, i) => <p key={i}>{l}</p>)}
        </div>
        <button onClick={onDismiss} aria-label="Dismiss" className="shrink-0 text-[var(--color-muted)] text-sm leading-none py-1">{'✕'}</button>
      </div>
    </div>
  )
}
