/* oxlint-disable react/refs -- session state is a mutable ref on purpose: the pose loop runs ~30x/s and must not close over stale React state; the component forces a re-render each frame. */
import { useEffect, useReducer, useRef, useState } from 'react'
import { startPoseLoop, POSE_CONNECTIONS } from '../lib/pose/poseEngine'
import { drawSkeleton } from '../lib/pose/drawSkeleton'
import { createDetectorFor } from '../lib/pose/detectorRegistry'
import { isBodyFramed } from '../lib/pose/landmarks'
import { CALIBRATION_MS, calibrateRest } from '../lib/pose/calibration'
import { buildTargets, cleanRateFor, nudgeNextTarget } from '../lib/pose/session'
import { storage } from '../lib/storage'
import { speak, stopSpeaking } from '../lib/voice'

const COLOR_CALIBRATING = '#facc15'
const COLOR_GOOD_FORM = '#4ade80'
const COLOR_BAD_FORM = '#ef4444'

// One exercise, from "how to" to summary:
//   howto -> calibrate (rep exercises) -> active -> rest -> active ... -> summary
// All camera data (frames, landmarks) is processed in this component and
// discarded. Only counts and scores leave it, through onFinish.
export default function CameraSession({ exercise, entry, onFinish, onCancel }) {
  const kind = exercise.kind === 'hold' ? 'hold' : 'reps'
  const unit = kind === 'hold' ? 's' : ''
  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const stopLoopRef = useRef(null)
  const streamRef = useRef(null)
  const frameRef = useRef(null)
  const apiRef = useRef(null)
  const wakeRef = useRef(null)
  const [det] = useState(() => createDetectorFor(exercise.id))
  const [, force] = useReducer((n) => n + 1, 0)
  const [status, setStatus] = useState('starting') // starting | running | error
  const [errorMessage, setErrorMessage] = useState('')
  const [voice, setVoice] = useState(() => storage.getPrefs().voice)
  const [selfCount, setSelfCount] = useState('')
  const voiceRef = useRef(voice)
  const rejectedTimer = useRef(null)

  const originalTarget = kind === 'hold' ? entry.holdSeconds ?? 30 : entry.reps ?? 10
  const S = useRef(null)
  if (S.current === null) {
    S.current = {
      stage: 'howto',
      targets: buildTargets(entry, kind),
      setNo: 0,
      repsInSet: 0,
      rejectedInSet: 0,
      heldMs: 0,
      elapsedMs: 0,
      holdStarted: false,
      results: [],
      totalRejected: 0,
      wasLow: false,
      faultDuringRep: false,
      phase: 'high',
      metric: null,
      personVisible: false,
      framed: false,
      fault: null,
      rejectedFlash: false,
      nudge: null,
      restLeft: 0,
      calStart: null,
      calSamples: [],
      calProgress: 0,
      calibration: null,
      calHint: null,
    }
  }
  const s = S.current

  // --- actions ---------------------------------------------------------
  function say(text, key) {
    if (voiceRef.current) speak(text, key)
  }

  function startSet() {
    det?.reset()
    Object.assign(s, {
      stage: 'active',
      repsInSet: 0,
      rejectedInSet: 0,
      heldMs: 0,
      elapsedMs: 0,
      holdStarted: false,
      wasLow: false,
      faultDuringRep: false,
      nudge: s.nudge,
    })
    say(`Set ${s.setNo + 1}. Go.`, 'set')
    force()
  }

  function finishSet() {
    if (s.stage !== 'active') return
    const target = s.targets[s.setNo]
    const counted = kind === 'hold' ? Math.round(s.heldMs / 1000) : s.repsInSet
    const clean =
      kind === 'hold'
        ? s.elapsedMs > 0
          ? Math.min(1, s.heldMs / s.elapsedMs)
          : null
        : cleanRateFor(s.repsInSet, s.rejectedInSet)
    s.results.push({
      target,
      counted,
      rejected: s.rejectedInSet,
      cleanRate: clean,
      trimmed: target !== originalTarget,
    })
    if (navigator.vibrate) navigator.vibrate(200)
    if (s.setNo + 1 < s.targets.length) {
      const nudge = nudgeNextTarget(originalTarget, target, clean)
      s.targets[s.setNo + 1] = nudge.target
      s.nudge = nudge.trimmed
        ? `Form slipped on that set, so the next one is trimmed to ${nudge.target}${unit}. Keep it clean.`
        : null
      s.setNo += 1
      s.stage = 'rest'
      s.restLeft = exercise.restSeconds ?? 40
      say(nudge.trimmed ? 'Set done. Next set is a little shorter.' : 'Set done. Rest.', 'set')
    } else {
      s.stage = 'summary'
      say('Exercise complete. Nice work.', 'set')
    }
    force()
  }

  function finishEarly() {
    // Record the partial set if anything happened in it.
    if (s.stage === 'active' && (s.repsInSet > 0 || s.heldMs > 0)) {
      const counted = kind === 'hold' ? Math.round(s.heldMs / 1000) : s.repsInSet
      s.partial = { target: s.targets[s.setNo], counted, rejected: s.rejectedInSet }
    }
    s.stage = 'summary'
    force()
  }

  function beginAfterHowTo() {
    if (kind === 'hold') {
      startSet()
    } else {
      s.stage = 'calibrate'
      s.calStart = null
      s.calSamples = []
      force()
    }
  }

  function skipCalibration() {
    const saved = storage.getCalibration(exercise.id)
    if (saved?.restValue != null) {
      det.setRestValue(saved.restValue)
      s.calibration = { used: true, restValue: saved.restValue, measured: saved.measured, fromSaved: true }
    } else {
      s.calibration = { used: false, restValue: det.restValue, measured: null, reason: 'skipped' }
    }
    startSet()
  }

  function collectCalibration(lm, now) {
    const m = det.readMetric(lm)
    if (m == null) return
    if (s.calStart == null) s.calStart = now
    s.calSamples.push(m)
    s.calProgress = Math.min(1, (now - s.calStart) / CALIBRATION_MS)
    if (now - s.calStart < CALIBRATION_MS) return

    const range = Math.abs(det.restValue - det.peakValue)
    const spread = Math.max(...s.calSamples) - Math.min(...s.calSamples)
    if (spread > 0.3 * range) {
      s.calStart = null
      s.calSamples = []
      s.calProgress = 0
      s.calHint = 'Hold still in the starting position.'
      return
    }
    const res = calibrateRest(s.calSamples, det.restValue, det.peakValue)
    if (res.used) {
      det.setRestValue(res.restValue)
      storage.saveCalibration(exercise.id, { restValue: res.restValue, measured: res.measured, at: Date.now() })
    }
    s.calibration = res
    startSet()
  }

  function processActive(lm, now) {
    const r = det.update(lm, now)
    if (!r.ok) return null
    s.metric = r.metric
    const fault = r.formOk === false ? r.formMessage : null

    if (kind === 'hold') {
      if (r.holding) s.holdStarted = true
      if (s.holdStarted) s.elapsedMs += r.dtMs ?? 0
      s.heldMs = r.heldMs
      s.phase = r.holding ? 'holding' : 'paused'
      if (fault) say(fault, 'fault')
      if (s.heldMs >= s.targets[s.setNo] * 1000) finishSet()
      return fault
    }

    s.phase = r.phase
    if (r.phase === 'low') {
      if (!s.wasLow) s.faultDuringRep = false
      s.wasLow = true
      if (r.formOk === false) s.faultDuringRep = true
    } else {
      s.wasLow = false
    }
    if (fault) say(fault, 'fault')

    if (r.repCompleted) {
      if (!s.faultDuringRep) {
        s.repsInSet += 1
        say(String(s.repsInSet), 'rep')
        if (s.repsInSet >= s.targets[s.setNo]) finishSet()
      } else {
        s.rejectedInSet += 1
        s.totalRejected += 1
        s.rejectedFlash = true
        clearTimeout(rejectedTimer.current)
        rejectedTimer.current = setTimeout(() => {
          s.rejectedFlash = false
          force()
        }, 1800)
      }
    }
    return fault
  }

  function onFrame(landmarks) {
    const hasLm = !!landmarks
    const isFramed = hasLm && isBodyFramed(landmarks)
    s.personVisible = hasLm
    s.framed = isFramed
    let fault = null
    const now = performance.now()

    if (isFramed && det) {
      if (s.stage === 'calibrate') collectCalibration(landmarks, now)
      else if (s.stage === 'active') fault = processActive(landmarks, now)
    } else if (s.stage === 'calibrate') {
      s.calStart = null
      s.calSamples = []
      s.calProgress = 0
    }
    s.fault = fault

    const canvas = canvasRef.current
    const video = videoRef.current
    if (canvas && video && video.videoWidth) {
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      const ctx = canvas.getContext('2d')
      if (!hasLm) ctx.clearRect(0, 0, canvas.width, canvas.height)
      else {
        const color = !isFramed ? COLOR_CALIBRATING : fault ? COLOR_BAD_FORM : COLOR_GOOD_FORM
        drawSkeleton(ctx, landmarks, POSE_CONNECTIONS, canvas.width, canvas.height, color)
      }
    }
    force()
  }

  function save() {
    const results = [...s.results]
    if (s.partial) results.push({ ...s.partial, cleanRate: cleanRateFor(s.partial.counted, s.partial.rejected), partial: true })
    const completeSets = s.results.length
    const counted = results.reduce((n, r) => n + (kind === 'hold' ? 0 : r.counted), 0)
    const heldSeconds = results.reduce((n, r) => n + (kind === 'hold' ? r.counted : 0), 0)
    const rejected = results.reduce((n, r) => n + (r.rejected ?? 0), 0)
    const rates = results.filter((r) => r.cleanRate != null)
    const cleanRate = rates.length ? rates.reduce((n, r) => n + r.cleanRate, 0) / rates.length : null
    const parsed = parseInt(selfCount, 10)
    onFinish({
      exerciseId: exercise.id,
      kind,
      setsPlanned: s.targets.length,
      setsCompleted: completeSets,
      repsCounted: counted,
      repsRejected: rejected,
      heldSeconds,
      cleanRate,
      trimmed: s.results.some((r) => r.trimmed),
      calibration: s.calibration
        ? { used: !!s.calibration.used, restValue: s.calibration.restValue, measured: s.calibration.measured ?? null }
        : null,
      selfCount: Number.isFinite(parsed) && parsed > 0 ? parsed : null,
    })
  }

  // keep the frame/timer callbacks pointing at the latest closures
  useEffect(() => {
    frameRef.current = onFrame
    apiRef.current = { startSet }
  })
  useEffect(() => {
    voiceRef.current = voice
    if (!voice) stopSpeaking()
  }, [voice])

  // rest countdown
  useEffect(() => {
    if (s.stage !== 'rest') return undefined
    const id = setInterval(() => {
      s.restLeft -= 1
      if (s.restLeft <= 0) {
        clearInterval(id)
        apiRef.current.startSet()
      } else force()
    }, 1000)
    return () => clearInterval(id)
  }, [s.stage, s])

  // camera + pose loop
  useEffect(() => {
    let cancelled = false
    async function start() {
      if (!navigator.mediaDevices?.getUserMedia) {
        setStatus('error')
        setErrorMessage('This browser does not support camera access. Try Chrome or Edge.')
        return
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        })
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop())
          return
        }
        streamRef.current = stream
        videoRef.current.srcObject = stream
        await videoRef.current.play()
        try {
          wakeRef.current = await navigator.wakeLock?.request('screen')
        } catch {
          /* optional */
        }

        const stop = await startPoseLoop(
          videoRef.current,
          ({ landmarks }) => frameRef.current?.(landmarks),
          () => {
            setStatus('error')
            setErrorMessage(
              'Could not load the pose detection model. It downloads once, so check your internet connection and try again.'
            )
          }
        )
        if (stop) {
          stopLoopRef.current = stop
          if (!cancelled) setStatus('running')
        }
      } catch (err) {
        if (cancelled) return
        setStatus('error')
        if (err.name === 'NotAllowedError') {
          setErrorMessage(
            'Camera access was blocked. Click the camera icon in the address bar, allow access, and try again.'
          )
        } else if (err.name === 'NotFoundError') {
          setErrorMessage('No camera was found on this device.')
        } else if (location.protocol === 'http:' && location.hostname !== 'localhost') {
          setErrorMessage('Camera access needs HTTPS or localhost.')
        } else {
          setErrorMessage('Could not access the camera.')
        }
      }
    }
    start()
    return () => {
      cancelled = true
      stopLoopRef.current?.()
      streamRef.current?.getTracks().forEach((t) => t.stop())
      wakeRef.current?.release?.().catch?.(() => {})
      clearTimeout(rejectedTimer.current)
      stopSpeaking()
    }
  }, [exercise.id])

  function stopCamera() {
    stopLoopRef.current?.()
    streamRef.current?.getTracks().forEach((t) => t.stop())
  }

  function handleCancel() {
    stopCamera()
    onCancel()
  }

  function handleSave() {
    stopCamera()
    save()
  }

  function toggleVoice() {
    const next = !voice
    setVoice(next)
    storage.savePrefs({ ...storage.getPrefs(), voice: next })
  }

  // --- derived display values -----------------------------------------
  const target = s.targets[s.setNo]
  const progressValue = kind === 'hold' ? Math.floor(s.heldMs / 1000) : s.repsInSet
  const progressPct = Math.min(100, (progressValue / target) * 100)
  const inCamera = s.stage === 'calibrate' || s.stage === 'active'

  let banner = null
  if (status === 'running' && inCamera) {
    if (s.rejectedFlash) banner = { tone: 'red', text: "That rep wasn't counted. Check your form and try again." }
    else if (!s.personVisible) banner = { tone: 'neutral', text: "Step into the camera's view" }
    else if (!s.framed) banner = { tone: 'yellow', text: 'Fit your whole body in frame. Checking your position…' }
    else if (s.fault) banner = { tone: 'red', text: s.fault }
    else if (s.stage === 'calibrate' && s.calHint) banner = { tone: 'yellow', text: s.calHint }
  }
  const bannerClass =
    banner?.tone === 'red'
      ? 'bg-red-500/90 text-white font-medium'
      : banner?.tone === 'yellow'
        ? 'bg-amber-400/90 text-[var(--color-ink)] font-medium'
        : 'bg-[var(--color-surface)]/90 text-[var(--color-cream)]'

  const totalCounted = s.results.reduce((n, r) => n + r.counted, 0) + (s.partial?.counted ?? 0)
  const totalRejected = s.results.reduce((n, r) => n + r.rejected, 0) + (s.partial?.rejected ?? 0)
  const clean = cleanRateFor(totalCounted, totalRejected)

  return (
    <div className="min-h-full flex flex-col bg-[var(--color-ink)]">
      <div className="relative flex-1 bg-black min-h-[55vh]">
        <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover -scale-x-100" playsInline muted />
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full -scale-x-100" />

        {status === 'starting' && (
          <div className="absolute inset-0 flex items-center justify-center text-[var(--color-cream)] text-sm px-6 text-center">
            Starting camera…
          </div>
        )}
        {status === 'error' && (
          <div className="absolute inset-0 flex items-center justify-center px-8">
            <p className="text-sm text-center text-[var(--color-cream)] max-w-xs leading-relaxed">{errorMessage}</p>
          </div>
        )}

        {banner && (
          <div className="absolute inset-x-0 bottom-6 flex justify-center px-6 pointer-events-none">
            <div className={`text-sm px-4 py-2 rounded-full text-center ${bannerClass}`}>{banner.text}</div>
          </div>
        )}

        {s.stage === 'calibrate' && status === 'running' && (
          <div className="absolute inset-x-0 top-16 flex justify-center px-6 pointer-events-none">
            <div className="bg-[var(--color-surface)]/90 text-sm px-4 py-2 rounded-2xl text-center max-w-xs">
              <span className="text-[var(--color-amber)] font-medium">Calibrating.</span> Hold the starting
              position for two seconds.
              <div className="h-1 rounded-full bg-[var(--color-surface-raised)] mt-2 overflow-hidden">
                <div className="h-full bg-[var(--color-amber)]" style={{ width: `${s.calProgress * 100}%` }} />
              </div>
            </div>
          </div>
        )}

        {s.stage === 'active' && s.nudge && s.repsInSet === 0 && s.heldMs === 0 && (
          <div className="absolute inset-x-0 top-16 flex justify-center px-6 pointer-events-none">
            <div className="bg-[var(--color-sage)]/95 text-[var(--color-ink)] text-sm font-medium px-4 py-2 rounded-2xl text-center max-w-xs">
              {s.nudge}
            </div>
          </div>
        )}

        <div className="absolute top-4 left-4 right-4 flex items-start justify-between gap-3">
          <div className="flex items-center gap-2">
            <RoundButton onClick={handleCancel} label="Cancel">{'✕'}</RoundButton>
            {exercise.howTo && (
              <RoundButton onClick={() => { s.prevStage = s.stage; s.stage = 'howto'; force() }} label="How to do this exercise">?</RoundButton>
            )}
            <RoundButton onClick={toggleVoice} label={voice ? 'Turn voice off' : 'Turn voice on'}>
              <SpeakerIcon on={voice} />
            </RoundButton>
          </div>
          <div className="shrink-0 rounded-full px-4 py-1.5 text-center font-display font-semibold bg-[var(--color-surface)]/85 text-[var(--color-cream)]">
            <span className="text-xs opacity-75 mr-2">Set {Math.min(s.setNo + 1, s.targets.length)}/{s.targets.length}</span>
            <span className="text-lg">{progressValue}</span>
            <span className="text-sm opacity-75">/{target}{unit}</span>
          </div>
        </div>

        {s.stage === 'howto' && exercise.howTo && status !== 'error' && (
          <div className="absolute inset-0 z-10 bg-black/85 flex items-center justify-center px-6">
            <div className="bg-[var(--color-surface)] rounded-2xl p-5 w-full max-w-xs">
              <p className="font-display text-lg font-semibold mb-1">{exercise.name}</p>
              <p className="text-xs text-[var(--color-muted)] mb-3">How to do it correctly:</p>
              <ol className="list-decimal list-inside space-y-2 text-sm leading-snug">
                {exercise.howTo.map((step, i) => (
                  <li key={i}>{step}</li>
                ))}
              </ol>
              {exercise.cameraTip && (
                <p className="text-xs text-[var(--color-sage)] mt-4 leading-relaxed">Camera: {exercise.cameraTip}</p>
              )}
              <button
                onClick={() => {
                  if (s.prevStage) { s.stage = s.prevStage; s.prevStage = null; force() } else beginAfterHowTo()
                }}
                className="w-full mt-5 font-display font-semibold px-4 py-2.5 rounded-full bg-[var(--color-amber)] text-[var(--color-ink)]"
              >
                {s.prevStage ? 'Back to the set' : "Got it, let's go"}
              </button>
            </div>
          </div>
        )}

        {s.stage === 'rest' && (
          <div className="absolute inset-0 z-10 bg-black/80 flex flex-col items-center justify-center px-6 text-center">
            <p className="text-sm text-[var(--color-muted)]">Rest</p>
            <p className="font-display text-7xl font-semibold text-[var(--color-amber)] tabular-nums">{s.restLeft}</p>
            <p className="mt-2 text-sm">
              Next: set {s.setNo + 1} of {s.targets.length}, {s.targets[s.setNo]}
              {kind === 'hold' ? ' seconds' : ' reps'}
            </p>
            {s.nudge && <p className="mt-3 text-sm text-[var(--color-sage)] max-w-xs leading-relaxed">{s.nudge}</p>}
            <button
              onClick={() => startSet()}
              className="mt-6 font-display font-semibold px-6 py-3 rounded-full bg-[var(--color-amber)] text-[var(--color-ink)]"
            >
              Start now
            </button>
          </div>
        )}

        {s.stage === 'summary' && (
          <div className="absolute inset-0 z-10 bg-black/85 flex items-center justify-center px-6">
            <div className="bg-[var(--color-surface)] rounded-2xl p-5 w-full max-w-xs">
              <p className="font-display text-lg font-semibold">{exercise.name}</p>
              <p className="text-xs text-[var(--color-muted)] mb-4">
                {s.results.length === s.targets.length ? 'All sets complete' : `${s.results.length} of ${s.targets.length} sets complete`}
              </p>
              <dl className="grid grid-cols-3 gap-2 text-center mb-4">
                <Stat label={kind === 'hold' ? 'Seconds held' : 'Reps counted'} value={kind === 'hold' ? s.results.reduce((n, r) => n + r.counted, 0) + (s.partial?.counted ?? 0) : totalCounted} />
                <Stat label={kind === 'hold' ? 'Breaks' : 'Not counted'} value={kind === 'hold' ? '-' : totalRejected} />
                <Stat label="Clean form" value={clean == null ? '-' : `${Math.round(clean * 100)}%`} />
              </dl>
              {kind === 'reps' && (
                <label className="block text-xs text-[var(--color-muted)] mb-4">
                  How many did you actually do? (optional, helps check the counter)
                  <input
                    type="number"
                    inputMode="numeric"
                    min="0"
                    value={selfCount}
                    onChange={(e) => setSelfCount(e.target.value)}
                    className="mt-1.5 w-full rounded-lg bg-[var(--color-ink)] border border-[var(--color-border)] px-3 py-2 text-sm text-[var(--color-cream)]"
                  />
                </label>
              )}
              <button
                onClick={handleSave}
                className="w-full font-display font-semibold px-4 py-2.5 rounded-full bg-[var(--color-amber)] text-[var(--color-ink)]"
              >
                Save and back to plan
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="px-6 py-5">
        <div className="flex items-end justify-between mb-3">
          <div>
            <p className="text-sm text-[var(--color-muted)]">{exercise.name}</p>
            <p className="font-display text-4xl font-semibold" style={{ color: progressPct >= 100 ? COLOR_GOOD_FORM : undefined }}>
              {progressValue}
              <span className="text-lg text-[var(--color-muted)] font-normal"> / {target}{unit}</span>
            </p>
          </div>
          <p className="text-xs text-[var(--color-muted)] text-right leading-relaxed shrink-0">
            {s.stage === 'calibrate' ? 'calibrating' : `phase: ${s.phase}`}
            {s.metric != null && (<><br />signal: {s.metric}</>)}
            {s.calibration?.used && (<><br />start: {s.calibration.restValue}</>)}
          </p>
        </div>
        <div className="h-1.5 rounded-full bg-[var(--color-surface-raised)] overflow-hidden">
          <div className="h-full rounded-full bg-[var(--color-amber)] transition-[width] duration-150" style={{ width: `${progressPct}%` }} />
        </div>

        {s.stage === 'calibrate' ? (
          <button onClick={skipCalibration} className="w-full mt-4 text-sm text-[var(--color-muted)] underline underline-offset-2 py-2">
            Skip calibration
          </button>
        ) : (
          <button
            onClick={finishEarly}
            disabled={s.stage === 'summary' || s.stage === 'howto'}
            className="w-full mt-4 font-display font-semibold px-6 py-3.5 rounded-full border border-[var(--color-amber)] text-[var(--color-amber)] disabled:opacity-40"
          >
            Finish exercise
          </button>
        )}
      </div>
    </div>
  )
}

function RoundButton({ onClick, label, children }) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      className="h-9 w-9 shrink-0 rounded-full bg-[var(--color-surface)]/80 flex items-center justify-center text-[var(--color-cream)] font-display font-semibold"
    >
      {children}
    </button>
  )
}

function Stat({ label, value }) {
  return (
    <div className="rounded-xl bg-[var(--color-ink)] py-2.5 px-1">
      <dd className="font-display text-xl font-semibold">{value}</dd>
      <dt className="text-[10px] text-[var(--color-muted)] leading-tight mt-0.5">{label}</dt>
    </div>
  )
}

function SpeakerIcon({ on }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M11 5 6 9H3v6h3l5 4V5z" />
      {on ? <path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13" /> : <path d="m16 9 5 6m0-6-5 6" />}
    </svg>
  )
}
