import { useState } from 'react'

const STEPS = ['goal', 'equipment', 'space', 'frequency']

const GOAL_OPTIONS = [
  { value: 'general_fitness', label: 'General fitness', blurb: 'Stay active, feel better day to day' },
  { value: 'strength', label: 'Build strength', blurb: 'Progressively harder resistance work' },
  { value: 'weight_loss', label: 'Weight loss', blurb: 'Higher-rep, full-body sessions' },
  { value: 'mobility', label: 'Mobility', blurb: 'Loosen up and move more freely' },
]

const EQUIPMENT_OPTIONS = [
  { value: 'none', label: 'None', blurb: 'Bodyweight only' },
  { value: 'resistance_band', label: 'Resistance band', blurb: '' },
  { value: 'dumbbells', label: 'Dumbbells', blurb: '' },
  { value: 'full_gym', label: 'Full home gym', blurb: '' },
]

const SPACE_OPTIONS = [
  { value: 'small', label: 'Small', blurb: 'A yoga-mat-sized area' },
  { value: 'medium', label: 'Medium', blurb: 'Room to stretch out and lunge' },
  { value: 'large', label: 'Large', blurb: 'A garage, garden, or open room' },
]

export default function Onboarding({ onComplete, initial = null, onExit = null, error = null }) {
  const [stepIndex, setStepIndex] = useState(0)
  const [profile, setProfile] = useState(
    initial ?? { goal: null, equipment: null, space: null, frequency: 3 }
  )

  const step = STEPS[stepIndex]
  const canGoNext =
    (step === 'goal' && profile.goal) ||
    (step === 'equipment' && profile.equipment) ||
    (step === 'space' && profile.space) ||
    step === 'frequency'

  function next() {
    if (stepIndex === STEPS.length - 1) {
      onComplete(profile)
    } else {
      setStepIndex((i) => i + 1)
    }
  }

  function back() {
    if (stepIndex === 0 && onExit) onExit()
    else setStepIndex((i) => Math.max(0, i - 1))
  }

  return (
    <div className="min-h-full flex flex-col px-6 py-10 max-w-md mx-auto">
      <ProgressDots total={STEPS.length} current={stepIndex} />

      <div className="flex-1 flex flex-col justify-center">
        {step === 'goal' && (
          <StepChoice
            title="What are you training for?"
            options={GOAL_OPTIONS}
            value={profile.goal}
            onChange={(v) => setProfile((p) => ({ ...p, goal: v }))}
          />
        )}

        {step === 'equipment' && (
          <StepChoice
            title="What equipment do you have?"
            options={EQUIPMENT_OPTIONS}
            value={profile.equipment}
            onChange={(v) => setProfile((p) => ({ ...p, equipment: v }))}
          />
        )}

        {step === 'space' && (
          <StepChoice
            title="How much space can you train in?"
            options={SPACE_OPTIONS}
            value={profile.space}
            onChange={(v) => setProfile((p) => ({ ...p, space: v }))}
          />
        )}

        {step === 'frequency' && (
          <FrequencyStep
            value={profile.frequency}
            onChange={(v) => setProfile((p) => ({ ...p, frequency: v }))}
          />
        )}
      </div>

      {error && <p className="text-sm text-red-400 pt-4" role="alert">{error}</p>}
      <div className="flex items-center justify-between pt-8">
        <button
          onClick={back}
          disabled={stepIndex === 0 && !onExit}
          className="text-sm text-[var(--color-muted)] disabled:opacity-0 px-2 py-2"
        >
          {stepIndex === 0 && onExit ? 'Cancel' : 'Back'}
        </button>
        <button
          onClick={next}
          disabled={!canGoNext}
          className="font-display font-semibold px-6 py-3 rounded-full bg-[var(--color-amber)] text-[var(--color-ink)] disabled:bg-[var(--color-surface-raised)] disabled:text-[var(--color-muted)] transition-colors"
        >
          {stepIndex === STEPS.length - 1 ? (initial ? 'Update my plan' : 'Build my plan') : 'Continue'}
        </button>
      </div>
    </div>
  )
}

function ProgressDots({ total, current }) {
  return (
    <div className="flex gap-1.5 mb-10" aria-hidden="true">
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className={`h-1 flex-1 rounded-full transition-colors ${
            i <= current ? 'bg-[var(--color-amber)]' : 'bg-[var(--color-surface-raised)]'
          }`}
        />
      ))}
    </div>
  )
}

function StepChoice({ title, options, value, onChange }) {
  return (
    <fieldset>
      <legend className="font-display text-2xl font-semibold mb-6 leading-snug">
        {title}
      </legend>
      <div className="flex flex-col gap-2.5">
        {options.map((opt) => {
          const selected = value === opt.value
          return (
            <button
              key={opt.value}
              type="button"
              onClick={() => onChange(opt.value)}
              aria-pressed={selected}
              className={`text-left px-4 py-3.5 rounded-xl border transition-colors ${
                selected
                  ? 'border-[var(--color-amber)] bg-[var(--color-surface-raised)]'
                  : 'border-[var(--color-border)] bg-[var(--color-surface)] hover:border-[var(--color-muted)]'
              }`}
            >
              <div className="font-medium">{opt.label}</div>
              {opt.blurb && (
                <div className="text-sm text-[var(--color-muted)] mt-0.5">{opt.blurb}</div>
              )}
            </button>
          )
        })}
      </div>
    </fieldset>
  )
}

function FrequencyStep({ value, onChange }) {
  return (
    <div>
      <h2 className="font-display text-2xl font-semibold mb-6 leading-snug">
        How many days a week?
      </h2>
      <div className="flex items-center justify-between gap-3">
        {[2, 3, 4, 5, 6].map((n) => (
          <button
            key={n}
            type="button"
            onClick={() => onChange(n)}
            aria-pressed={value === n}
            className={`h-14 w-14 rounded-full font-display font-semibold text-lg transition-colors ${
              value === n
                ? 'bg-[var(--color-amber)] text-[var(--color-ink)]'
                : 'bg-[var(--color-surface)] border border-[var(--color-border)]'
            }`}
          >
            {n}
          </button>
        ))}
      </div>
      <p className="text-sm text-[var(--color-muted)] mt-4">
        You can change this later from the plan screen. The plan adjusts to what you actually complete.
      </p>
    </div>
  )
}
